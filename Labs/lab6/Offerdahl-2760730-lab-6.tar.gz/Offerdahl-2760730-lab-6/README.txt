//*****************************************************************************
//
//		Author: Jay Offerdahl
//		Class:	EECS 560 (Data Structures)
//		Lab:	Tues. 11a - 12:50p
//		Lab #: 	6
//
//*****************************************************************************

KUID: 2760730

Hello Mehrdad!

I've included the program output, the hand drawn report, and a brief discussion
about the lab in the included pdf.

To run the program, of course, run the makefile using "make" then "./lab", and
follow the on screen instructions. (There's two options, hah!)

Thanks for taking the time to discuss the depth first search with me, as I said
in the report, I thought I was being really clever by figuring out some spots
would be missed, but in reality, I simply did the lab wrong to begin with.

See you next week,

Jay