//*****************************************************************************
//
//		Author: Jay Offerdahl
//		Class:	EECS 560 (Data Structures)
//		Lab:	Tues. 11a - 12:50p
//		Lab #: 	7
//
//*****************************************************************************

KUID: 2760730

Hello Mehrdad!

I've included the report as PDF per usual (now anyways). As always there are
no command line args, and I include the output for parts 1 and 2 in the report
as part of the program. 

Enjoy your spring break, and I'll see you next week,

Jay