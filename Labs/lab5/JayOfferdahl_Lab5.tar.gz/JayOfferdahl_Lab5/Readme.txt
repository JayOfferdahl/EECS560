Author: Jay Offerdahl
KUID: 2760730

Lab 5 ReadMe


Hello!

I don't implement any command line parameters with this program, so to compile,
all that is needed is to run the make file. 

In my main.cpp file, I've included two variables at the top of the main function
to help with testing the comparisons between the two data structures. If the 
boolean value is set to false, you're not in testing mode, if it's true, you are.

Lastly, if you want to view the distance algorithm output, simple set testing mode
to false and the output from the input file will appear in the console on program
launch.

Thanks for taking the time to read this, and if you have any questions please
email me at jayofferdahl@ku.edu.

Thanks!

Jay