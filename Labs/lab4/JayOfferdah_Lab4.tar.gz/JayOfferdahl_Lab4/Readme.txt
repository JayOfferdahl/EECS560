Author: Jay Offerdahl
KUID: 2760730

Lab 4 ReadMe


Hello!

I don't implement any command line parameters with this program, so to compile,
all that is needed is to run the make file. 

As shown in my project report, my data file lab4.data.txt populates the two
data structures and they are printed out once. Next, there's a while loop to
handle user interaction.

Thanks for taking the time to read this, and if you have any questions please
email me at jayofferdahl@ku.edu.

Thanks!

Jay