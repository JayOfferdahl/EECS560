//*****************************************************************************
//
//		Author: Jay Offerdahl
//		Class:	EECS 560 (Data Structures)
//		Lab:	Tues. 11a - 12:50p
//		Lab #: 	13/14
//
//*****************************************************************************

KUID: 2760730

Hello Mehrdad!

This is the first part of the program, which includes the insert method for the
pairing heap data structure. I have setup some test code for testing in main.

To make and run the program:

make
./lab

Thanks, and see you next week,

Jay