//*****************************************************************************
//
//		Author: Jay Offerdahl
//		Class:	EECS 560 (Data Structures)
//		Lab:	Tues. 11a - 12:50p
//		Proj #: 2
//
//*****************************************************************************

Hello!

Thanks for taking the time to read this file, as it contains important
information about my project. 

To run the program:

make
./proj2 proj2data.txt  			// or whatever datafile you want to input

These commands will produce all the output that I have outlined in the written
report, however, if you want to add your own commands or testing parameters, 
please follow the following instructions:

* No blank lines
* Options on one line, input for that option on the next line

** Assumes correct input format for each command

I input the phonebook.txt data into the hash tables before running the file
commands, so feel free to test the data in there as well.

As stated in the written report, if you have any questions or troubles, feel
free to contact my by email: jayofferdahl@ku.edu or phone (573) - 673 - 5212.

Thanks!